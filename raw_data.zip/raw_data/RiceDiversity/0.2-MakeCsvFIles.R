library(psych)
library(rrBLUP)

### load data
GenoMat <- read.csv("DATA/sativas_genome_imputed_MISSING_0.9_MAF_0.05.tsv", sep = "\t")
PhenoMat <- read.csv("RAWDATA/RiceDiversity_44K_Phenotypes_34traits_PLINK.txt", sep = "\t")

### make the same ID
n.line <- nrow(PhenoMat)
n.snp <- nrow(GenoMat)
# visually check
as.character(PhenoMat$HybID) # ID in the phenotype info
colnames(GenoMat)[-(1:9)] # ID in the genotype info

## modification (I visually checked the difference to write below)
# remove "@" from phenotype IDs
PhenoMat$HybID <- as.character(PhenoMat$HybID)
PhenoMat$HybID[382:n.line] <- substr(PhenoMat$HybID[382:n.line], 2, 1000)
# modify genotype IDs (1~381 line) 
pos_underbar <- regexpr("_", colnames(GenoMat)[-(1:9)][1:381])
name_trim <- substr(colnames(GenoMat)[-(1:9)][1:381], 2, pos_underbar-1)
name_sub <- gsub("[.]", "-", name_trim)
sum(name_sub != PhenoMat$HybID[1:381]) # OK!
colnames(GenoMat)[-(1:9)][1:381] <- name_sub
# modify genotype IDs (382~413 line) 
pos_underbar2 <- regexpr("_", colnames(GenoMat)[-(1:9)][382:n.line])
name_trim2 <- substr(colnames(GenoMat)[-(1:9)][382:n.line], 3, pos_underbar2-1)
sum(name_trim2 != PhenoMat$HybID[382:n.line]) # OK!
colnames(GenoMat)[-(1:9)][382:n.line] <- name_trim2
# check
colnames(GenoMat)[-(1:9)] == PhenoMat$HybID # OK!

### Check input genotype data
GenoMat[1:10, 1:10] # the first 9 cols are info of markers.
dim(GenoMat) # so there are 29,564 SNPs for 413 (422 - 9 = 413) varieties.
# some plots (meaningless)
barplot(table(GenoMat$X.CHROM))
plot(GenoMat$POS)

### Check input phenotype data
PhenoFinal <- PhenoMat[, 2:ncol(PhenoMat)] # remove HybID
dim(PhenoFinal) # there are 413 lines, 3 traits.


### now I attach NSFTVID for genotype.
colnames(GenoMat)[-(1:9)] <- PhenoMat$NSFTVID
GenoMat_Final <- cbind("MrkID" = GenoMat$ID,
                       "Chr" = GenoMat$X.CHROM,
                       "Pos" = GenoMat$POS,
                       GenoMat[, -(1:9)])
dim(GenoMat_Final) # now we focus on the 413 (416 - 3 = 413) lines, 29,564 SNPs.
ScoreMat <- GenoMat_Final[, -(1:3)]
prod(dim(ScoreMat)) == (sum(ScoreMat == 1) + sum(ScoreMat == 0) + sum(ScoreMat == -1)) # no missings

### relationship matrx
ReMat <- A.mat(t(GenoMat_Final[, -(1:3)]))

### below is equivalent to A.mat
# --------------------------------------------------------------- #
#freq <- apply(ScoreMat + 1, 1, sum) / (2 * ncol(ScoreMat))
#summary(freq)
#W <- ScoreMat + (1 - 2 * freq)
#A <- tcrossprod(t(W)) / (2 * sum(freq * (1 - freq)))
# --------------------------------------------------------------- #

### save data as csv format
write.csv(x = PhenoFinal, file = "RESULT/pheno.csv", row.names = F)
write.csv(x = GenoMat_Final, file = "RESULT/geno.csv", row.names = F)
write.csv(x = ReMat, file = "RESULT/relationship_matrix.csv")


