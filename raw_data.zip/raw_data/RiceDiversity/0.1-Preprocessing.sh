#!/bin/sh

## This is a code for data processing such as converting format, filtering, and imputaion.
## Rawdata was downloaded from RiceDiversity 44K_SNP dataset

## 1. Convert the raw data (.map, .ped, .fam format) to .vcf format by using PLINK
## CAUTION: PLINK version 1.09 is required!! (not to use 1.07; stable version)
## Prepare two directories: RAWDATA which contains input files (.ped & .map) and DATA (empty; for saving results)
# Path for PLINK
export PATH=$PATH:/Applications/plink_mac

# Load rawdata in PLINK and make a binary file
plink --ped RAWDATA/sativas413.ped --map RAWDATA/sativas413.map  --make-bed --out DATA/sativas_binary

# Convert binary files to vcf format. 
plink --bfile DATA/sativas_binary --recode vcf --out DATA/sativas_out


## 2. Filtering by using vcftools
vcftools --vcf DATA/sativas_out.vcf --min-alleles 2 --max-alleles 2 --remove-indels --maf 0.05 --max-missing 0.9 --recode --out DATA/sativas_MISSING_0.9_MAF_0.05


## 3. Impuation by using beagle
java -jar /Applications/beagle.27Jan18.7e1.jar gt=DATA/sativas_MISSING_0.9_MAF_0.05.recode.vcf out=DATA/sativas_MISSING_0.9_MAF_0.05.recode.imputed


## 4. Convert vcf file to tsv format by using vcftools
gzcat DATA/sativas_MISSING_0.9_MAF_0.05.recode.imputed.vcf.gz | grep -v "##" | sed 's/0|0/-1/g' | sed 's/0|1/0/g' | sed 's/1|0/0/g' | sed 's/1|1/1/g' > DATA/sativas_genome_imputed_MISSING_0.9_MAF_0.05.tsv
gzcat DATA/sativas_MISSING_0.9_MAF_0.05.recode.imputed.vcf.gz | grep -v "##" | grep "#" > DATA/sativas_genome_indv_MISSING_0.9_MAF_0.05.txt
gzcat DATA/sativas_MISSING_0.9_MAF_0.05.recode.imputed.vcf.gz | grep -v "##" | cut -f1,2 > DATA/sativas_genome_pos_MISSING_0.9_MAF_0.05.txt



